package com.example.coffeeapp.Database;

public class OrderContract {

    public OrderContract(){

    }
    public static final String="com.example.coffeeapp";
    public
}
