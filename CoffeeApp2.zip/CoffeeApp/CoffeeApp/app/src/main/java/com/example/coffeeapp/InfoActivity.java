package com.example.coffeeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class InfoActivity extends AppCompatActivity {

    ImageView imageView;
    ImageButton plusquantity, minusquantity;
    TextView quantitynumber, drinkName, coffeePrice;
    CheckBox addToppings, addExtraCream;
    Button addtoCart;
    int quantity;
    public Uri mCurrentCartUri;
    boolean hasAllRequiredValues = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        imageView = findViewById(R.id.imageViewInfo);
        plusquantity = findViewById(R.id.addquantity);
        minusquantity = findViewById(R.id.subquantity);
        quantitynumber = findViewById(R.id.quantity);
        drinkName = findViewById(R.id.drinkNameinInfo);
        coffeePrice = findViewById(R.id.coffeePrice);
        addToppings = findViewById(R.id.addToppings);
        addtoCart = findViewById(R.id.addtocart);
        addExtraCream = findViewById(R.id.addCream);


        drinkName.setText("Green Tea");


        addtoCart.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InfoActivity.this,SummaryActivity.class);
                startActivity(intent);
            }
        });

        plusquantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int basePrice = 5;
                quantity++;
                displayQuantity();
                int coffePrice = basePrice * quantity;
                String setnewPrice = String.valueOf(coffeePrice);
                coffeePrice.setText(setnewPrice);

                int ifCheckBox = CalculatePrice(addExtraCream, addToppings);
                coffeePrice.setText("₵ " + ifCheckBox);


            }
        });
        minusquantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int basePrice = 5;
                if (quantity == 0) {
                    Toast.makeText(InfoActivity.this, "Cant decrease quantity < 0", Toast.LENGTH_SHORT).show();
                } else {
                    quantity--;
                    displayQuantity();
                    int coffePrice = basePrice * quantity;
                    String setnewPrice = String.valueOf(coffeePrice);
                    coffeePrice.setText(setnewPrice);

                    int ifCheckBox = CalculatePrice(addExtraCream, addToppings);
                    coffeePrice.setText("₵ " + ifCheckBox);


                }
            }
        });
    }

    private int CalculatePrice(CheckBox addExtraCream, CheckBox addToppings) {
        int basePrice = 5;

        if (addExtraCream.isChecked()) {
            basePrice = basePrice + 2;

        }

        if (addToppings.isChecked()) {
            basePrice = basePrice + 3;
        }
        return basePrice * quantity;
    }

        private void displayQuantity() {
            quantitynumber.setText(String.valueOf(quantity));

        }


    }

